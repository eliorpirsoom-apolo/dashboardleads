<?php
/**
 * Plugin Name: Danit Hason – Projects CPT
 * Description: רושם מחדש את סוג התוכן "פרויקטים" (projects) שנמחק בעקבות עדכון תבנית. שומר את כל תוכן הפרויקטים הקיים במסד הנתונים ומחזיר אותו לתצוגה. מומלץ שלא למחוק תוסף זה.
 * Version: 1.0.0
 * Author: Apollo / Elior
 * Text Domain: danit-projects-cpt
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // אין גישה ישירה
}

/**
 * רישום סוג התוכן "פרויקטים".
 * ה-slug חייב להישאר בדיוק "projects" — זהו הסוג שבו שמורים כל הפוסטים הקיימים.
 */
function danit_register_projects_cpt() {

	$labels = array(
		'name'               => 'פרויקטים',
		'singular_name'      => 'פרויקט',
		'menu_name'          => 'פרויקטים',
		'add_new'            => 'הוספת פרויקט',
		'add_new_item'       => 'הוספת פרויקט חדש',
		'edit_item'          => 'עריכת פרויקט',
		'new_item'           => 'פרויקט חדש',
		'view_item'          => 'צפייה בפרויקט',
		'search_items'       => 'חיפוש פרויקטים',
		'not_found'          => 'לא נמצאו פרויקטים',
		'not_found_in_trash' => 'לא נמצאו פרויקטים בפח',
		'all_items'          => 'כל הפרויקטים',
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'show_in_rest'       => true,
		'has_archive'        => false,
		'hierarchical'       => false,
		'menu_position'      => 5,
		'menu_icon'          => 'dashicons-portfolio',
		'capability_type'    => 'post',
		'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes', 'custom-fields' ),
		'taxonomies'         => array( 'category' ),
		'rewrite'            => array( 'slug' => 'projects', 'with_front' => false ),
	);

	register_post_type( 'projects', $args );
}
add_action( 'init', 'danit_register_projects_cpt' );

/**
 * בהפעלת התוסף: לרשום את הסוג ואז לרענן את מבנה הקישורים,
 * כדי שעמודי הפרויקטים יעבדו מיד בלי צעד ידני נוסף.
 */
function danit_projects_activate() {
	danit_register_projects_cpt();
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'danit_projects_activate' );

/**
 * בכיבוי התוסף: לנקות את מבנה הקישורים (התוכן עצמו לא נמחק).
 */
function danit_projects_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'danit_projects_deactivate' );
